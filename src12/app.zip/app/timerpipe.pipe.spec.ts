import { TimerpipePipe } from './timerpipe.pipe';

describe('TimerpipePipe', () => {
  it('create an instance', () => {
    const pipe = new TimerpipePipe();
    expect(pipe).toBeTruthy();
  });
});
