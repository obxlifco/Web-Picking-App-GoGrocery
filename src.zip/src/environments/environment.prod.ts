export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBSkqZieZtJzzmzi-5cNricYeoujrHtRG4",
    authDomain: "myapp-f8321.firebaseapp.com",
    databaseURL: "https://myapp-f8321.firebaseio.com",
    projectId: "myapp-f8321",
    storageBucket: "myapp-f8321.appspot.com",
    messagingSenderId: "638529687242",
    appId: "1:638529687242:web:b3e293c0a53704b42dee33"
  }
  // Initialize Firebase
};
