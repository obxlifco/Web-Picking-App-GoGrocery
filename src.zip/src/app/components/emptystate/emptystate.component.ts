import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emptystate',
  templateUrl: './emptystate.component.html',
  styleUrls: ['./emptystate.component.scss']
})
export class EmptystateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
